# Avikal_devops_project

This is a sample DevOps project demonstrating CI/CD with GitHub Actions using a Flask app and Docker.